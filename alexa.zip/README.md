# techolympics-alexa

https://developer.amazon.com/alexa-skills-kit/alexa-skill-quick-start-tutorial

step 1
5-12 will be out of order
author from scratch, name it
name roll, basic edge lambda permissions
disable skill ID (relevant for production, not our uses)

step 2
8 use intents.json (not the data they provide)
9-11 skip
12 use utterances.txt (not the data they provide)

